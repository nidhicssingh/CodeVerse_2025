import pywhatkit

# Get a summary about Python
pywhatkit.info("Python programming language", lines=10)
