import pywhatkit
pywhatkit.search("Best Python IDEs")
