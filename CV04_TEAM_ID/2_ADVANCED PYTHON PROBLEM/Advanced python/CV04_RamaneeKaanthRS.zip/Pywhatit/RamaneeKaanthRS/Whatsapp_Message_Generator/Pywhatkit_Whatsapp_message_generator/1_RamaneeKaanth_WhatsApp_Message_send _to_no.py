import pywhatkit

# Send a WhatsApp Message to a Contact at 10:50 AM

pywhatkit.sendwhatmsg("+919281038881", 
					"Hey there, I'm RamaneeKaanth, this is a test message sent using my python script!", 
					15, 47)
 
