import pywhatkit
 
# Same as above but Closes the Tab in 60 Seconds after Sending the Message
pywhatkit.sendwhatmsg("+918754973733", "Hi", 9, 23
                      , 15, True, 15)
#
