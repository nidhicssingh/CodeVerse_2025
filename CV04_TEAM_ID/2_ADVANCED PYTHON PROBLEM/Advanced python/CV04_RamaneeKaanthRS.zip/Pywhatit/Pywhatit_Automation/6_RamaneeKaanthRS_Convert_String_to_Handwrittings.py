import pywhatkit

# Convert string to handwriting and save it as an image
pywhatkit.text_to_handwriting("Hello RamaneeKaanth, this is Python magic!", save_to="handwriting.png")

print("Handwriting image saved as 'handwriting.png'")
