from pywhatkit import image_to_ascii_art

image_to_ascii_art(
    r'C:\Users\raman\Documents\Pywhatit\Pywhatit_Automation\Flower.jpg',
    r'C:\Users\raman\Documents\Pywhatit\Pywhatit_Automation\ascii_output'
)
