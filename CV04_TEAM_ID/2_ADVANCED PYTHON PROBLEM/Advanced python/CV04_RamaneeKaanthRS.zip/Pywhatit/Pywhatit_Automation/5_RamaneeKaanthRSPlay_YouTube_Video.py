import pywhatkit
pywhatkit.playonyt("peaceful space")