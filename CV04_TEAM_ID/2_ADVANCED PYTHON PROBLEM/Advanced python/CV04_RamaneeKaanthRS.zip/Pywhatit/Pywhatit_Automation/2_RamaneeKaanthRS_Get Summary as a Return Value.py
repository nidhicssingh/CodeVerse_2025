import pywhatkit
info = pywhatkit.info("deep learning", lines=5, return_value=True)
print("Summary:\n", info)
