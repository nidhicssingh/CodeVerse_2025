import pywhatkit
pywhatkit.text_to_handwriting("Hello, Nidhi!", save_to="E:/CodeVerse/Hands on python/2_1_2_pywhatkit_Automation/output.png")
