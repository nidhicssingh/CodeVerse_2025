def like(post):
    post['likes'] += 1
