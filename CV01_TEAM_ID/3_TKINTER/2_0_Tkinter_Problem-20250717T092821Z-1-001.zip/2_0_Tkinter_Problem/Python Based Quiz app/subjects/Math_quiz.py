# subjects/math_quiz.py

quiz_data = [
    {
        "question": "What is 5 + 7?",
        "options": ["10", "11", "12", "13"],
        "answer": "12"
    },
    {
        "question": "What is square root of 64?",
        "options": ["6", "8", "9", "10"],
        "answer": "8"
    }
]
