# subjects/math_quiz.py

quiz_data = [
    {
        "question": "What is the correct way to create a function in Python?",
        "options": ["function myFunc():", "def myFunc:", "def myFunc():", "create myFunc():"],
        "answer": "def myFunc():"
    },
    {
        "question": "Which of these is a correct variable name in Python?",
        "options": ["1value", "value_1", "value-1", "@value"],
        "answer": "8"
    }
]
